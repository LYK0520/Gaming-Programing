#include"RussianCubeGameDetail.h"
#include"RussianCubeGame.h"
#include"10-1-3Tetris.h"
int main()
{
    Game tetris;
    tetris.gameRun();
    //getchar();
    //system("pause");
    return 0;
}