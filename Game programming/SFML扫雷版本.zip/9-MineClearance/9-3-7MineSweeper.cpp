#include"Game.cpp"

int main()
{
    Game Mine;
    Mine.Run();
}